#######################################################
### Multi-task learning network
### Mathias Lindholm, Ronald Richman, Andreas Tsanakas, Mario W�thrich
### May 19, 2022
#######################################################
 
KL.divergence <- function(pred, true){(sum(pred)-sum(true)+sum(log((true/pred)^(true))))/length(pred)}

plot.loss <- function(pos0, loss, rr, ylim0, plot.yes=0, filey1, col0){
  if (plot.yes==1){pdf(filey1)}      
  plot(loss$val_loss,col=col0[2], ylim=ylim0, main=list(paste("SGD algorithm: run ",rr,sep=""), cex=1.5),xlab="training epochs", ylab="deviance loss", cex=1.5, cex.lab=1.5)
  lines(loss$loss,col=col0[1])
  legend(x=pos0, col=col0, lty=c(1,-1), lwd=c(1,-1), pch=c(-1,1), legend=c("training loss", "validation loss"))
  if (plot.yes==1){dev.off()}          
   }


plot.smokers.portfolio <- function(dat, XX, y0=c(.1,.7), probab){
  dd <- ddply(dat[which(dat$X2==XX),], .(X1), summarize, obs=mean(Y), DFIP=mean(DFIP2), Unaware=mean(Unaware2))
  dd1 <- ddply(dat[which((dat$D==1)&(dat$X2==XX)),], .(X1), summarize, obs=mean(Y), pred2=mean(Pred2), true=mean(True))
  dd0 <- ddply(dat[which((dat$D==0)&(dat$X2==XX)),], .(X1), summarize, obs=mean(Y), pred2=mean(Pred2), true=mean(True))
  smokers <- "smokers"
  if (XX==0){smokers <- "non-smokers"}
  title0 <- paste("multi-task FNN: ",smokers," (",(1-probab)*100,"% NA in D)", sep="")  
  plot(x=dd1[,1], y=dd1[,3], lwd=2,  col="blue", type='l', ylim=y0, ylab="frequency", xlab="ages", main=list(title0, cex=1.5), cex.lab=1.5) # observed female
  lines(x=dd0[,1], y=dd0[,3],lwd=2,  col="cyan")         # best estimate male
  lines(x=dd0[,1], y=dd1[,4], col="blue", lty=3)         # best estimate male
  lines(x=dd0[,1], y=dd0[,4], col="cyan", lty=3)         # best estimate male
  lines(x=dd[,1], y=dd[,4],lwd=2,  col="orange")         # unawareness
  lines(x=dd[,1], y=dd[,3],lwd=2,  col="red")            # discrimination-free
  legend(x="bottomright", cex=1.2, lwd=rep(2,4), col=c("blue","cyan","orange","red"), legend=c("best-estimate D=female", "best estimate D=male", "unawareness", "discrimination-free"))
  }


##########################################
######### plain-vanilla neural network
##########################################

plain.vanilla.network <- function(seed, q0, activation, lambda0){
    set.seed(seed)
    set_random_seed(seed)
    Design  <- layer_input(shape = c(q0[1]), dtype = 'float32', name = 'Design') 
    #
    Network = Design %>% 
          layer_dense(units=q0[2], activation=activation, name='hidden1') %>%
          layer_dense(units=q0[3], activation=activation, name='hidden2') %>%
          layer_dense(units=q0[4], activation=activation, name='hidden3') %>%
          layer_dense(units=1, activation='exponential', name='Network', 
                weights=list(array(0, dim=c(q0[4],1)), array(log(lambda0), dim=c(1))))
    #
    keras_model(inputs = c(Design), outputs = c(Network))
    }

##########################################
######### multi-task neural network
##########################################

multi.task.network <- function(seed, q0, activation, lambda0, pp){
    set.seed(seed)
    set_random_seed(seed)
    Design  <- layer_input(shape = c(q0[1]), dtype = 'float32', name = 'Design') 
    #
    Network = Design %>% 
          layer_dense(units=q0[2], activation=activation, name='hidden1A') %>%
          layer_dense(units=q0[3], activation=activation, name='hidden2A') %>%
          layer_dense(units=q0[4], activation=activation, name='hidden3A') %>%                                                
          layer_dense(units=q0[5], activation='exponential', name='Network', 
                weights=list(array(0, dim=c(q0[4],q0[5])), array(log(lambda0), dim=c(q0[5]))))
    #
    DFIP = Network %>% 
          layer_dense(units=1, activation='linear', use_bias=FALSE, trainable=FALSE,
                weights=list(array(c(pp,1-pp), dim=c(2,1))), name='DFIP')   
    #
    GenderProb = Design %>% 
          layer_dense(units=q0[2], activation=activation, name='hidden1B') %>%
          layer_dense(units=q0[3], activation=activation, name='hidden2B') %>%
          layer_dense(units=q0[4], activation=activation, name='hidden3B') %>%                                                
          layer_dense(units=1, activation='sigmoid', name='NetworkP', 
                weights=list(array(0, dim=c(q0[4],1)), array(log(pp/(1-pp)), dim=c(1))))                
    #
    Genders = GenderProb %>%
          layer_dense(units=2, activation='linear', trainable=FALSE,
               weights=list(array(c(1,-1), dim=c(1,2)), array(c(0,1), dim=c(2))))
    #
    Unaware = list(Network, Genders) %>% layer_multiply() %>%
          layer_dense(units=1, activation='linear', use_bias=FALSE, trainable=FALSE,
                weights=list(array(c(1,1), dim=c(2,1))), name='Unaware')   
    #
    Output = list(Network, DFIP, GenderProb, Unaware) %>% layer_concatenate()         
    #
    keras_model(inputs = c(Design), outputs = c(Output))
    }


