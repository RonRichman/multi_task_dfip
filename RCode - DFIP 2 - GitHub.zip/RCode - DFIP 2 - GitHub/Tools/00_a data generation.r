#######################################################
### Generate synthetic health data 
### Mathias Lindholm, Ronald Richman, Andreas Tsanakas, Mario W�thrich
### May 19, 2022
#######################################################
# load libraries
library(keras)
library(tensorflow)
library(plyr)

# set parameters
alpha0 <- c(-40,38.5,38.5)
beta0 <- c(-2, 0.004, 0.1, 0.2)
gamma0 <- c(-2, 0.01)
ages <- c(15:80)           # ages of policyholders
nAges <- length(ages)
womanProp <- 0.45          # women ratio
smokerProp <- 0.3          # smoker proportion
womanSmokerProp <- 0.8     # woman conditional on smoking
womanNonSmokerProp <- (womanProp-womanSmokerProp*smokerProp)/(1-smokerProp)

#######################################################
### simulate portfolio and claims from the (true) model
#######################################################

nPolicies <- 100000
agePattern <- dnorm(x = ages / 100, mean = 0.45, sd = 0.2)
ageProp <- agePattern / sum(agePattern)

X <- matrix(0, nrow = nPolicies, ncol = 2)
D <- matrix(0, nrow = nPolicies, ncol = 1)

set.seed(100)
(nWomen <- rbinom(n = 1, size = nPolicies, prob = womanProp))
(nSmokingWomen <- rbinom(n = 1, size = nWomen, prob = womanSmokerProp * smokerProp / womanProp))
(nSmokingMen <- rbinom(n = 1, size = nPolicies - nWomen, prob = (1 - womanSmokerProp) * smokerProp / (1 - womanProp)))
(probWoman <- nWomen / nPolicies)

D[1 : nWomen] <- 1
X[, 1] <- matrix(ages, nrow = 1, ncol = nAges) %*% rmultinom(n = nPolicies, size = 1, prob <- ageProp)
X[1 : nSmokingWomen, 2] <- 1
X[(nWomen + 1) : (nWomen + 1 + nSmokingMen), 2] <- 1

logLambda1 <- alpha0[1] + alpha0[2] * (X[, 1] >= 20) * (X[, 1] <= 40) * D + alpha0[3] * (X[, 1] >= 60) * (X[, 1] <= 80) * (1-D)
logLambda2 <- beta0[1]+ beta0[2] * X[, 1] + beta0[3] * X[, 2] + beta0[4] * D
logLambda3 <- gamma0[1] + gamma0[2] * X[, 1]

X1 <- X[, 1]
X2 <- X[, 2]

Y <- rpois(n = nPolicies, lambda = exp(logLambda1) + exp(logLambda2) + exp(logLambda3))

fullData <- data.frame(Y = Y, X1 = X1, X2 = X2, D = D)
fullData$True <- as.vector(exp(logLambda1) + exp(logLambda2) + exp(logLambda3))
# randomize order of portfolio
set.seed(50)
fullData <- fullData[sample(1:nrow(fullData)),] 
fullData$Id <- c(1:nrow(fullData))
fullData <- fullData[,c("Id","X1","X2","D","True","Y")]

