#######################################################
### Discrimination-free insurance pricing 
### Mathias Lindholm, Ronald Richman, Andreas Tsanakas, Mario W�thrich
### August 2, 2022
#######################################################

## generate the synthetic health insurance data
source(file="./Tools/00_a data generation.R")

str(fullData)

## load functions for FNN fitting
source(file="./Tools/00_b networks and functions.R")

#######################################################
### data pre-processing for network modeling
#######################################################

dat <- fullData

## MinMaxScaler of continuous age variable
dat$X1Net <- 2*(dat$X1-min(dat$X1))/(max(dat$X1)-min(dat$X1))-1

# homogeneous empirical frequency
(lambda.hom <- mean(dat[,"Y"]))
# female ratio
(pp <- mean(dat$D))


#################################################################################
#########  random gender removal
#################################################################################

probab <- 0.3      # ratio of available discriminatory information

set.seed(1234)
dat$D_Available <- rbinom(nrow(dat), 1, p=probab)

#################################################################################
### naive plain-vanilla network fitting dropping NAs
#################################################################################


# choose covariates
XX    <- as.matrix(dat[,c("X1Net","X2","D")])
XX0   <- as.matrix(dat[which(dat$D_Available==1),c("X1Net","X2","D")])
# choose response
YY0   <- as.matrix(dat[which(dat$D_Available==1),"Y"])
# choose network architecture
q00   <- c(ncol(XX), c(20,15,10))
seed  <- 100
model <- plain.vanilla.network(seed, q00, 'relu', lambda.hom)
#
path0 <- paste("./Networks/plain_vanilla_network", sep="")
CBs <- callback_model_checkpoint(path0, monitor = "val_loss", verbose = 0,  save_best_only = TRUE, save_weights_only = TRUE)
model %>% compile(loss = 'poisson', optimizer = 'nadam')
## fitting procedure (may be time consuming)
#{t1 <- proc.time()
#     fit <- model %>% fit(XX0, YY0, validation_split=0.2, 
#                        batch_size=50, epochs=200, verbose=0, callbacks=CBs)
#(proc.time()-t1)[3]}
## plot stochastic gradient descent losses 
#plot.loss("topright", fit[[2]], 1, ylim0=range(fit[[2]]), plot.yes=0, "", col0=c("blue","darkgreen"))
# callback optimal network
load_model_weights_hdf5(model, path0)
# best-estimate prediction
dat$Pred1 <- as.vector(model %>% predict(XX))
# discrimination-free pricing
XX1 <- XX
XX1[,3] <- 1
BEFemale <- as.vector(model %>% predict(XX1))
XX1[,3] <- 0
BEMale <- as.vector(model %>% predict(XX1))
(p0 <- mean(XX0[,3]))
dat$DFIP1 <- as.vector(BEFemale) * p0 + as.vector(BEMale) * (1-p0) 
       
#################################################################################
### multi-task network fitting dropping NAs
#################################################################################

Poisson_Binary_GenderNA_Loss <- function(y_true, y_pred){
   k_mean(y_true[,3]*((y_pred[,1]-y_true[,1]*k_log(y_pred[,1]))*y_true[,2] + (y_pred[,2]-y_true[,1]*k_log(y_pred[,2]))*(1-y_true[,2]))+
          (y_pred[,5]-y_true[,1]*k_log(y_pred[,5])) -
          y_true[,3]*(y_true[,2]*k_log(y_pred[,4])+(1-y_true[,2])*k_log(1-y_pred[,4])))
    }


# choose covariates
XX    <- as.matrix(dat[,c("X1Net","X2")])
# choose response
YY    <- as.matrix(dat[,c("Y", "D", "D_Available")])    #D=1 is female
## population distribution P[D] is in pp0
q00   <- c(ncol(XX), c(20,15,10, 2))
model <- multi.task.network(seed, q00, 'relu', c(lambda.hom,lambda.hom), p0)
#
path0 <- paste("./Networks/multi_task_network", sep="")
CBs <- callback_model_checkpoint(path0, monitor = "val_loss", verbose = 0,  save_best_only = TRUE, save_weights_only = TRUE)
model %>% compile(loss = Poisson_Binary_GenderNA_Loss, optimizer = 'nadam')
## fitting procedure (may be time consuming)
#{t1 <- proc.time()
#     fit <- model %>% fit(XX, YY, validation_split=0.2, 
#                        batch_size=50, epochs=200, verbose=0, callbacks=CBs)
#(proc.time()-t1)[3]}
## plot stochastic gradient descent losses 
#plot.loss("topright", fit[[2]], 1, ylim0=range(fit[[2]]), plot.yes=0, "", col0=c("blue","darkgreen"))
# callback optimal network
load_model_weights_hdf5(model, path0)
pred <- as.matrix(model %>% predict(XX))
dat$Pred2   <- as.vector(pred[,1]) * dat$D + as.vector(pred[,2]) * (1-dat$D)
dat$DFIP2    <- as.vector(pred[,3])
dat$Unaware2 <- as.vector(pred[,5])


#################################################################################
# results: KL divergences to the true model
#################################################################################


t(rbind( round(c(KL.divergence(dat$Pred1,dat$True)*1000, KL.divergence(dat$DFIP1,dat$True)*1000, NA), 4),
       round(c(KL.divergence(dat$Pred2,dat$True)*1000, KL.divergence(dat$DFIP2,dat$True)*1000, KL.divergence(dat$Unaware2,dat$True)*1000), 4)))




plot.smokers.portfolio(dat, XX=1, y0=c(.1,.8), probab)
plot.smokers.portfolio(dat, XX=0, y0=c(.1,.8), probab)
